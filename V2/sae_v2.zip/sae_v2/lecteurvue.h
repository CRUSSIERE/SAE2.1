#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class lecteurvue; }
QT_END_NAMESPACE

class lecteurvue : public QMainWindow
{
    Q_OBJECT

public:
    lecteurvue(QWidget *parent = nullptr);
    ~lecteurvue();

public slots:
    void precedent();
    void suivant();
    void demarrerModeAuto();
    void arreterModeAuto();

private:
    Ui::lecteurvue *ui;
};
#endif // LECTEURVUE_H
