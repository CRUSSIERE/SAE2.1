#include "lecteurvue.h"
#include "ui_lecteurvue.h"

lecteurvue::lecteurvue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::lecteurvue)
{
    ui->setupUi(this);

    connect(ui->bPrecedent,SIGNAL(clicked()), this, SLOT(precedent()));
    connect(ui->bSuivant,SIGNAL(clicked()), this, SLOT(suivant()));
    connect(ui->bDemarrerModeAuto,SIGNAL(clicked()), this, SLOT(demarrerModeAuto()));
    connect(ui->bArreterModeAuto,SIGNAL(clicked()), this, SLOT(arreterModeAuto()));
}

lecteurvue::~lecteurvue()
{
    delete ui;
}

void lecteurvue::precedent(){
    return qDebug("precedent");
}

void lecteurvue::suivant(){
    return qDebug("suivant");
}

void lecteurvue::demarrerModeAuto(){
    return qDebug("demarrermodeauto");
}

void lecteurvue::arreterModeAuto(){
    return qDebug("arretermodeauto");
}
